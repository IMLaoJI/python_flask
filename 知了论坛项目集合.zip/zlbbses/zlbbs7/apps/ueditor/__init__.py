#encoding: utf-8

from .ueditor import bp